package com.miapp.reservashotel.model;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}


