package com.miapp.reservashotel.dto;

public record RatingSummaryDTO(double average, long count) {}

